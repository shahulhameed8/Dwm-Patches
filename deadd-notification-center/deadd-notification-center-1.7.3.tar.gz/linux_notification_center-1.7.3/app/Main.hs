module Main where

import qualified NotificationCenter

main :: IO ()
main = NotificationCenter.main
